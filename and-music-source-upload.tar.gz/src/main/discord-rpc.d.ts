declare module 'discord-rpc'
